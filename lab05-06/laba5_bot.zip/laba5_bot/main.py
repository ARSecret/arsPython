import logging
import time
import random
from sys import exit
from aiogram.types import *
from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.middlewares.logging import LoggingMiddleware

TOKEN = '5012836949:AAHzd5kE4JMgdzc4CyDk0nRdmK5d258mvjw'
if not TOKEN:
    exit('Error: no token provided')

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s")

# Initialize bot and dispatcher
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())


@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    """
    This handler will be called when user sends `/start` command
    """
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add('⌚ Узнать время')
    keyboard.add('🎲 Сыграть в игру')
    await message.answer("Привет, я тестовый бот реализующий функционал кнопок. \n"
                         "Я могу показать вам время и \"бросить монетку\". \n"
                         "Используйте кнопки снизу: ", reply_markup=keyboard)


@dp.message_handler(commands=['help'])
async def send_help(message: types.Message):
    '''
    This handler will be called when user sends `/help` command
    :param message:
    :return:
    '''
    await message.answer("Help here!")


@dp.message_handler(lambda message: message.text == '⌚ Узнать время')
async def show_time(message: types.Message):
    await message.answer(time.strftime('Сейчас %H:%M'))


@dp.message_handler(lambda message: message.text == '🎲 Сыграть в игру')
async def start_game(message: types.Message):
    keyboard = InlineKeyboardMarkup(row_width=2)

    keyboard.add(InlineKeyboardButton('Орёл', callback_data=f'Орёл'),
                 InlineKeyboardButton('Решка', callback_data=f'Решка'))
    await message.answer('Выберите сторону:', reply_markup=keyboard)


@dp.callback_query_handler(text='Орёл')
async def func5(call: types.CallbackQuery):
    # орёл == 0
    # решка == 1
    t = random.randint(0, 1)
    if t:
        await call.message.answer(f'Бот выбросил {"Решку" if t else "Орла"}!\n'
                                  f'Вы не угадали!')
    else:
        await call.message.answer(f'Бот выбросил {"Решку" if t else "Орла"}!\n'
                                  f'Вы угадали!')
    await call.answer()


@dp.callback_query_handler(text='Решка')
async def func6(call: types.CallbackQuery):
    # орёл == 0
    # решка == 1
    t = random.randint(0, 1)
    if t:
        await call.message.answer(f'Бот выбросил {"Решку" if t else "Орла"}!\n'
                                  f'Вы угадали!')
    else:
        await call.message.answer(f'Бот выбросил {"Решку" if t else "Орла"}\n'
                                  f'Вы не угадали!')
    await call.answer()


'''

@dp.callback_query_handler(text=[bond+'2' for bond in unique_names])
async def func4(call: types.CallbackQuery):
    await call.message.answer('Я вторая функция!')
    await call.answer()

'''


@dp.message_handler()
async def nothing(message: types.Message):
    await message.answer('Я не знаю такой команды.')


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
